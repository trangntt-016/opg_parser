package paths;


public interface Paths{
	public class FilePaths {
			public final static String commonTypeFile = "./CommonTypes.xsd";
			public final static String eplFile = "./EPL.xsd";
			public final static String accessRightsByProfile = "./Access rights by profile.xml";
			public final static String permissionJSON = "./permissions.json";
	}
	
}
